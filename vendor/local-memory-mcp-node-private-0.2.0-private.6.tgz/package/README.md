# Local Memory MCP — private TypeScript candidate

Source candidate **0.2.0-private.6**, Node **>=22.13.0**. This revision removes the added application-level journal and its dependent reliable-host/coordinated-snapshot APIs. No replacement recovery framework is provided. Ordinary history, conflicts, search receipts, reconciliation and scope backup/restore remain. Nothing has been published.

One local CPU ONNX embedding/reranking pair serves independently bound Chat and global collections. The standalone MCP service remains an independent product. Trusted hosts supply their own live Chat/Agent/Run authority through the exported adapters. Stores share inference resources; no third workflow store is required.

## Install and run

See [installation](docs/INSTALLATION.md) for package installation, explicit model preparation, MCP configuration and offline prerequisites. Chroma HTTP server is a separate dependency; JavaScript does not open Python PersistentClient directories. The tested pairing is JS chromadb3.5.0 with Chroma server1.4.1. SQLite remains explicitly experimental.

```json
{
  "mcpServers": {
    "local-memory": {
      "command": "node",
      "args": ["/absolute/consumer/node_modules/@local-memory/mcp-node-private/dist/src/server.js"],
      "env": {
        "MEMORY_STORAGE": "chroma",
        "MEMORY_CHROMA_URL": "http://127.0.0.1:8001",
        "MEMORY_MODEL_DIR": "/absolute/pinned-models",
        "MEMORY_STATE_DIR": "/absolute/owned-state",
        "MEMORY_SCOPE": "global",
        "MEMORY_COLLECTION_PREFIX": "my-isolated-memory"
      }
    }
  }
}
```

Replace paths with absolute paths for your OS. First-time creation requires explicit MEMORY_PROVISION=1; ordinary reopen omits it and refuses missing stores. HTTP mode (--http) provides /mcp and legacy /sse with bearer/OAuth options. Standalone owner tools bind to the configured store; they are not a multiuser authorization layer.

## Retrieval and operating contract

Authorized collections receive equal candidate budgets. Search merges before one cross-encoder rerank and preserves IDs, scope and provenance. Historical relevance is retained; newest does not automatically win. Confidence filtering follows the merged candidate cutoff. Missing/incompatible authorized collections fail instead of partial success. Ambiguous cross-store IDs require a scope selector.

list_chunks enumerates original text/metadata with scope-qualified identity and snapshot cursors. Enumeration/backup/maintenance can transiently materialize rows; self-check is quadratic. Default discovery excludes optional index tools; automatic semantic generation is deferred. No broad quality or TypeScript RAM advantage claim is made.

See [host consumption](docs/HOST_CONSUMPTION.md), [migration and backup](docs/MIGRATION_RECOVERY.md), [portability](docs/PORTABILITY.md), [license review](docs/LICENSE_REVIEW.md) and [third-party inventory](THIRD_PARTY_NOTICES.md).

Shared TypeScript supports a common source design; runtime acceptance is measured separately per platform. Linux is the authorized test environment. No cross-platform or native-notice clearance is implied.

## Development and private packaging

In an isolated source copy on the authorized test machine, install locked dependencies, run npm test, then npm run package:private. The package stays private:true. Packaging builds and creates a local tarball without registry publication. Offline installation needs a prepared dependency cache, target native libraries, exact model assets and separately prepared Chroma. Runtime does not download models.

Preserve previous sealed artifacts/evidence. Identify consumers by exact archive hash; version alone is insufficient. This preparation does not authorize a live migration, deployment or release.

