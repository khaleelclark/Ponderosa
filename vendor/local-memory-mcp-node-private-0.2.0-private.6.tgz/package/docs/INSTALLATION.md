# Installation and offline operation

This is private candidate source preparation, not a published package. Pine access recovered; private.4 builds and offline scripts-disabled dependency installation passed. Clean consumer and runtime acceptance require the hash-bound release-preparation report. Earlier private.3 Linux results apply to that exact archive only.

## Dependencies

Use Node >=22.13.0 and a compatible local Chroma HTTP server. JavaScript client3.5.0 with server1.4.1 was tested on Pine. Include the separate server's disk/RAM in sizing. Do not point this candidate at production storage.

When a qualified private tarball is supplied, install it in an owned consumer directory:

```text
npm install --ignore-scripts --no-audit --no-fund /absolute/path/to/candidate.tgz
```

Add --offline only with a complete prepared cache for the target platform. This CPU-only scripts-disabled approach worked for sealed private.3 on Linux; Windows/macOS acceptance remains unrun; private.4 Linux acceptance is recorded separately. ONNX Runtime has an install script that can fetch additional native libraries. Disabling scripts avoids that implicit download; required CPU libraries must already be included and load successfully. A Linux node_modules tree is not portable to other platforms. See [portability](PORTABILITY.md).

## Explicit model preparation

This separate installer action uses the network. From the consumer directory:

```text
node ./node_modules/@local-memory/mcp-node-private/scripts/install-models.mjs /absolute/owned-model-directory
```

It downloads only tokenizer.json, tokenizer_config.json and float32 onnx/model.onnx for each model, verifies sizes/SHA256s from contracts/models.json and reuses matching cached files. It does not select quantized weights. Those six files total **182,595,767 bytes (174.14 MiB)**. Node, dependencies, Chroma and state are additional. The manifest lists other investigation assets that this installer does not download. See [model licensing](LICENSE_REVIEW.md) before redistributing a model bundle.

For offline inference, prepare exact files under embed/ and rerank/ first. Runtime verifies local hashes and refuses missing/corrupt files; it does not import the downloader. Dependency installation and Chroma setup have independent offline prerequisites.

## Stdio and stores

Use the MCP JSON example in the [README](../README.md), replacing paths with OS-appropriate absolute paths. MEMORY_STATE_DIR controls default backup/OAuth state, not Chroma storage. MEMORY_BACKUP_DIR overrides backup location. MEMORY_COLLECTION_PREFIX identifies physical store namespace and must remain stable across reopen. MEMORY_SCOPE defaults to global. A Chat scope can add global reads with MEMORY_READ_GLOBAL=1.

For a brand-new disposable destination, set MEMORY_PROVISION=1 for first start. Omit it on ordinary reopen. Preserve URL/prefix/scope inventory. Startup checks both models and required collections; missing known stores do not permit recreation.

## HTTP

Add --http. MCP_BIND_HOST and MCP_BIND_PORT control listening (port8000 by default). Routes are /mcp, /sse and /messages/. Authentication defaults to none; select bearer or OAuth explicitly. This guidance does not change routing, credentials or network exposure.

- Bearer: MCP_AUTH_MODE=bearer and owner-supplied MCP_BEARER_TOKEN.
- OAuth: MCP_AUTH_MODE=oauth, MCP_OAUTH_CLIENT_ID, MCP_OAUTH_CLIENT_SECRET, JSON MCP_OAUTH_REDIRECT_ALLOWLIST, MCP_ISSUER_URL and optional MCP_RESOURCE_SERVER_URL.
- Optional JSON MCP_ALLOWED_HOSTS configures allowed host names.

Keep real secrets out of examples/source/logs. Transport authentication does not replace a host's per-Chat/Run authority.

## Removed legacy configuration

MEMORY_JOURNAL_DIR is rejected even when empty. The runtime rejects a supplied journal property. Existing directories are never opened, deleted, adopted or recovered. Remove obsolete settings deliberately; this revision provides no application crash-recovery guarantee. Use the ordinary scope backup APIs only within their documented limits.
