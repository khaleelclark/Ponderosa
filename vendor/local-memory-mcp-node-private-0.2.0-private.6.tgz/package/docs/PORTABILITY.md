# Runtime and platform boundaries

The core uses shared TypeScript with explicit Chroma HTTP storage and local cached ONNX inference. Node>=22.13 remains because the independent experimental MemoryDatabase backend imports built-in node:sqlite; its existing database WAL is not an application journal or newly introduced substitute. Chroma is the normal supported storage choice; sqlite-prototype remains explicitly gated and does not open Chroma databases.

The application journal, external flock helper and lifetime SQLite journal owner/envelope have been removed. There is no application ownership/recovery service or journal OS gate. Existing legacy settings refuse; no old directory is touched. Ordinary backup/file permissions, native library availability and external Chroma support retain their platform assumptions. Linux Node22.22.1/24.16.0 tests are reported separately; macOS/Windows acceptance, power loss, filesystem faults, remote filesystems and native distribution notice closure remain unqualified. Source portability is not proof of platform acceptance.

No performance benchmark is repeated. Earlier private.4 figures apply to those exact artifacts only. Default installed dependencies may contain other-platform native payloads; runtime platform selection does not remove their distribution obligations. See license review and the separate unsealed native-notice investigation.
