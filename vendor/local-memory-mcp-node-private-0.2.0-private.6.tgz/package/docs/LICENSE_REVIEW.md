# License review — source preparation, not publication clearance

Reviewed on 2026-10-19. Package source includes an MIT LICENSE; private.4 preparation adds package.json license:MIT. It remains private:true. Prior archives are unchanged.

## Exact dependency declarations

Official npm version metadata was read for every non-development entry in the exact private.3 lock, including optional platform packages and repeated nested dependencies. All 115 metadata versions and distribution-integrity values matched the lock. This is **declaration review**, not an audit of installed license/NOTICE texts or native embedded dependencies. No package was downloaded/installed/executed for this review.

| Declaration | Locked runtime entries |
| --- | ---: |
| MIT | 100 |
| Apache-2.0 | 2 |
| ISC | 8 |
| BSD-3-Clause | 3 |
| BSD-2-Clause | 1 |
| MIT OR CC0-1.0 | 1 |

Direct declarations: @huggingface/tokenizers0.2.0 Apache-2.0; MCP SDK1.32.1 MIT; ajv8.17.1 MIT; chromadb3.5.0 Apache-2.0; express5.2.1 MIT; onnxruntime-node1.27.0 MIT. The [full metadata inventory](DEPENDENCY_LICENSE_METADATA.json) binds exact package paths, versions, official metadata URLs, metadata hashes, lock integrities and optional/platform fields. The upstream registry declaration does not guarantee every bundled native component has the same license.

Before distributing an installed/bundled application: inspect exact installed LICENSE/COPYING/NOTICE files and ONNX/Chroma native third-party notices, retain required texts/attributions and notices, identify any modified third-party files, and record hashes. Optional target binaries and ONNX install-time fetched components need their own inventory. For an ordinary npm package, dependencies are installed separately; that differs from bundling node_modules/native binaries in an application. This preparation includes an inventory, not fabricated complete third-party license texts.

## Pinned models

Both publisher repositories declare Apache-2.0 at the pinned revisions:

- sentence-transformers/all-MiniLM-L6-v2, revision1110a243fdf4706b3f48f1d95db1a4f5529b4d41: [pinned model card](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/blob/1110a243fdf4706b3f48f1d95db1a4f5529b4d41/README.md).
- cross-encoder/ms-marco-MiniLM-L6-v2, revision233902d25c440f23af6f7d6e94d2946bac0bee0a: [pinned repository declaration](https://huggingface.co/cross-encoder/ms-marco-MiniLM-L6-v2/tree/233902d25c440f23af6f7d6e94d2946bac0bee0a).

The reranker pinned README did not load through the research tool; the pinned file-tree page supplied its declaration. Top-level tree listings did not show LICENSE/NOTICE files; nested/native payload notice inspection remains open. Model binaries are not in this package. The explicit installer downloads pinned original tokenizer and ONNX files and does not itself copy model license/attribution files into the model directory. A redistributable model bundle therefore needs its own retained license and attribution material, tied to the exact artifacts.

For an Apache-2.0 redistribution, retain the license and applicable notices/attribution and identify modifications; verify whether upstream NOTICE material applies. See the authoritative [Apache-2.0 redistribution terms](https://www.apache.org/licenses/LICENSE-2.0). Publisher model licensing declarations are recorded; no independent claim about training-data rights or complete redistribution clearance is made.

## Remaining evidence

Pine access recovered. Exact installed inspection found 111 runtime package entries on Linux and retained 108 LICENSE/NOTICE files under docs/third-party; the four absent optional platform entries are not Linux-installed. Chroma native bindings1.3.4, onnxruntime-common1.27.0 and onnxruntime-node1.27.0 do not ship top-level license texts in their installed payloads. The ONNX v1.27.0 upstream LICENSE and ThirdPartyNotices are included as supplemental upstream material, not proof of exact compiled binary component closure. Chroma native source-tag LICENSE fetch returned404; exact native bundled-license completeness remains a distribution gate. See installed audit in release evidence. Both pinned model cards, Apache license and repository revision attribution are packed; upstream pinned manifests list no LICENSE/NOTICE paths. Clean consumer results are recorded separately. Public naming, publication and bundled-model distribution require an explicitly reviewed artifact; none happened in this task.
