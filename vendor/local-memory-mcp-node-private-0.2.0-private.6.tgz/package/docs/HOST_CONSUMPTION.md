# Trusted host consumption

One MemoryRuntime owns a shared embedding/reranking pair and physical stores. PonderosaMemory and createMemoryToolAdapter from /ponderosa remain the thin host boundary. The trusted host supplies live chat identity, authorization and source classification; tool/model arguments cannot route to another chat. Writes require explicit chat/global destination and current grants; global write defaults denied. Read provenance and ambiguous-ID source selection remain explicit. Drain calls before closing shared runtime.

Configure storage:chroma with explicit URL/collection prefix/create policy, local modelDir and backupDir. Ready validates/provisions authorized scopes. Ordinary reopen uses create:false. The standalone MCP owner interface is distinct from multi-chat host authority.

Removed /reliability exported ReliableMemoryHost/createReliableMemoryToolAdapter and their durable logical-ID/receipt/revision machinery; /backup coordinated snapshot and /durable-storage APIs are gone. No replacement persistence is introduced. Ordinary chunk IDs/version history and per-service search warning receipts are retained; search receipts are not durable command idempotency receipts.

Saved private host integration-review/current/local-memory.ts and its shared-chat copy import /reliability and configure journal:{directory:c.journalDirectory}; runtime-selection.ts selects the reliable catalog. Those consuming-package contracts require an owner-authored change outside this candidate. This revision is NOT a drop-in replacement for that private host. Synthetic thin-adapter qualification is separate; no V6/live files are modified. Do not recreate removed durability guarantees in a compatibility shim.

Authorization/abort checks cannot atomically coordinate host policy and Chroma HTTP writes. Chroma operations are not server transactions. Host native state coordination, live deployment and external policy database acceptance are not qualified here.
