#!/usr/bin/env node
// Explicit opt-in download step; the runtime never imports this module.
import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
const destination=process.argv[2];
if(!destination)throw new Error('Usage: npm run models:install -- /absolute/model-directory');
const root=path.resolve(destination);
const manifest=JSON.parse(fs.readFileSync(new URL('../contracts/models.json',import.meta.url)));
for(const [kind,model] of Object.entries(manifest))for(const name of ['tokenizer.json','tokenizer_config.json','onnx/model.onnx']){
 const file=model.files.find(f=>f.path===name);if(!file)throw new Error('Incomplete model manifest');
 const target=path.join(root,kind,name);fs.mkdirSync(path.dirname(target),{recursive:true});
 if(fs.existsSync(target)&&createHash('sha256').update(fs.readFileSync(target)).digest('hex')===file.sha256)continue;
 const url=`https://huggingface.co/${model.repo}/resolve/${model.revision}/${name}`;
 const response=await fetch(url);if(!response.ok)throw new Error(`Model download failed: ${response.status}`);
 const bytes=Buffer.from(await response.arrayBuffer());
 if(bytes.length!==file.bytes||createHash('sha256').update(bytes).digest('hex')!==file.sha256)throw new Error(`Model hash mismatch: ${kind}/${name}`);
 const temp=target+'.'+randomUUID()+'.tmp';fs.writeFileSync(temp,bytes,{mode:0o600});fs.renameSync(temp,target);
 console.log(`Installed pinned ${kind}/${name}`);
}
